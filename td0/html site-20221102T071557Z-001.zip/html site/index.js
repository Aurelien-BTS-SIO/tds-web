const closebutton = document.getElementsByAll('.material-symbols-outlined')
closebutton.addEventListener("onclick", close)


const close = (e) => {
    console.log("je clique")
}